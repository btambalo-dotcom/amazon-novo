from amazon_flex import create_app
app = create_app()
